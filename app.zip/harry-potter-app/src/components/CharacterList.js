import React from 'react';

function CharacterList({ characters }) {
  return (
    <div>
      {characters.length > 0 ? (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {characters.map((char, index) => (
            <li
              key={index}
              style={{
                border: '1px solid #ccc',
                margin: '10px 0',
                padding: '10px',
                borderRadius: '5px',
                backgroundColor: '#f9f9f9',
              }}
            >
              <h3>{char.name}</h3>
              <p>House: {char.house}</p>
              <p>{char.detail}</p>
            </li>
          ))}
        </ul>
      ) : (
        <p>No characters found for this house.</p>
      )}
    </div>
  );
}

export default CharacterList;
