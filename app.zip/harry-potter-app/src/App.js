import React, { useState } from 'react';
import CharacterList from './components/CharacterList';
import characters from './data/characters';

function App() {
  const [houseFilter, setHouseFilter] = useState('');

  const handleFilterChange = (e) => {
    setHouseFilter(e.target.value);
  };

  const filteredCharacters = characters.filter((char) =>
    houseFilter === '' ? true : char.house === houseFilter
  );

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Harry Potter Characters</h1>
      <div>
        <label htmlFor="houseFilter">Filter by house: </label>
        <select
          id="houseFilter"
          value={houseFilter}
          onChange={handleFilterChange}
        >
          <option value="">All</option>
          <option value="Gryffindor">Gryffindor</option>
          <option value="Slytherin">Slytherin</option>
          <option value="Hufflepuff">Hufflepuff</option>
          <option value="Ravenclaw">Ravenclaw</option>
        </select>
      </div>
      <CharacterList characters={filteredCharacters} />
    </div>
  );
}

export default App;
