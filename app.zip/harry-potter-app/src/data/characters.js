const characters = [
  { name: 'Harry Potter', house: 'Gryffindor', detail: 'The Boy Who Lived' },
  { name: 'Hermione Granger', house: 'Gryffindor', detail: 'Muggle-born genius' },
  { name: 'Ron Weasley', house: 'Gryffindor', detail: 'Loyal friend' },
  { name: 'Draco Malfoy', house: 'Slytherin', detail: 'Prideful pure-blood' },
  { name: 'Luna Lovegood', house: 'Ravenclaw', detail: 'Quirky and wise' },
  { name: 'Cedric Diggory', house: 'Hufflepuff', detail: 'Honorable and brave' },
  { name: 'Severus Snape', house: 'Slytherin', detail: 'Master of Potions' },
];

export default characters;
