const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Simulated Harry Potter characters
const characters = [
    { name: "Harry Potter", house: "Gryffindor" },
    { name: "Hermione Granger", house: "Gryffindor" },
    { name: "Ron Weasley", house: "Gryffindor" },
    { name: "Draco Malfoy", house: "Slytherin" }
];

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// API endpoint to fetch characters
app.get('/api/characters', (req, res) => {
    res.json(characters);
});

// Serve the index.html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});